export class Profile {
    constructor(public prId: string, public prName: string) {
    }
}
