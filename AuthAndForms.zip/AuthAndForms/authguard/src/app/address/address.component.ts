import { Component } from '@angular/core';
@Component({
  template: `
      <h3>ADDRESS</h3>
      <p><b> Chennai </b></p>
	  
  `
})
export class AddressComponent { 
}
    