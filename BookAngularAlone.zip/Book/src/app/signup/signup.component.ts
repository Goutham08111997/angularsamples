import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import {users} from '../site/users'
import { UserServiceService } from '../site/user-service.service';
import { Router } from '@angular/router';
import { AuthService } from '../site/auth.service';
// import {} from '../site/login/login.component'

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {


  passwordMismatch : string;
  signupForm : FormGroup;
  user : users = {
    username : "",
    firstname : "",
    lastname : "",
    password : "",
    role : "Customer"
  };
  //router : Router;
  constructor(public userService : UserServiceService , public authService : AuthService, public router : Router) { }

  ngOnInit() {
    this.signupForm = new FormGroup ({
      'username' : new FormControl(this.user.username,[Validators.required, Validators.maxLength(20)]),
      'firstname' : new FormControl(this.user.firstname,[Validators.required, Validators.pattern('^[a-zA-Z]+$'),Validators.maxLength(50)]),
      'lastname' : new FormControl(this.user.lastname,[Validators.required, Validators.pattern('^[a-zA-Z]+$'),Validators.maxLength(50)]),
      'password' : new FormControl(this.user.password,[Validators.required]),
      'confirmPassword' : new FormControl(null,[Validators.required])
    })
  }

  OnSignUp()
 {
 
   if(this.signupForm.value.password == this.signupForm.value.confirmPassword) {
    this.user.username = this.signupForm.value.username;
     this.user.firstname = this.signupForm.value.firstname;
     this.user.lastname = this.signupForm.value.lastname;
     this.user.password = this.signupForm.value.password;
     this.user.role = "Customer";
     this.userService.addUser(this.user);
     //console.log(this.user);
    this.router.navigate([this.authService.redirectUrlLogin])
}
else {
  this.passwordMismatch = "Password and Confirm Password must be same"
}
 }}
