import { Book } from '../book/book';

export interface cart  {
    cartItems : Book[],
    totalPrice : number;
}