import { Component, OnInit } from '@angular/core';
import { CartserviceService } from '../cartservice.service';
import { cart } from '../cart';

@Component({
  selector: 'app-shopping-cart',
  templateUrl: './shopping-cart.component.html',
  styleUrls: ['./shopping-cart.component.css']
})
export class ShoppingCartComponent implements OnInit {
  cart:cart;
  cartItemRemoved = false;
  
  constructor(private cartservice : CartserviceService) { }
  removeCartItem (id:number){
    this.cartservice.removeCartItem(id);
    this.cartItemRemoved =  true;
  }
  calculateTotalPrice(): number
 {
  return this.cartservice.calculateTotalPrice()
 }
  ngOnInit() {
    this.cart = this.cartservice.getCart();
  }

}
