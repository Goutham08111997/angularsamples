import { Injectable } from '@angular/core';
import { cart } from './cart';
import { Book } from '../book/book';
import { BookserviceService } from '../book/bookservice.service';

@Injectable({
  providedIn: 'root'
})
export class CartserviceService {
   totalPrice : number;
   bookCart : Book;
  cart : cart = {
    cartItems : [{
      id: 101,
    name: "C Programming",
    price:99,
    active:true,
    dateOfPublications:new Date('03/15/2017'),
    category:'Programming',
    freeDelivery:true,
    url:'https://images.unsplash.com/photo-1528735602780-2552fd46c7af?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60'
  },
{id: 102,
  name: "Java",
  price:129,
  active:true,
  dateOfPublications:new Date('12/23/2017'),
  category:'Programming',
  freeDelivery:false,
  url:'https://images.unsplash.com/photo-1512152272829-e3139592d56f?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=500&q=60'
},
{
  id: 103,
  name: "Database",
  price:149,
  active:true,
  dateOfPublications:new Date('08/21/2017'),
  category:'Database',
  freeDelivery:true,
   url:'https://images.unsplash.com/photo-1534308983496-4fabb1a015ee?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=500&q=60'
}],
totalPrice: 0
  }
getCart() : cart {
  this.cart.totalPrice = this.calculateTotalPrice();
  return this.cart;
}
 calculateTotalPrice() : number {
   this.totalPrice = 0;
   for(let item of this.cart.cartItems) {
     this.totalPrice += item.price;
   }
   return this.totalPrice;

 } 
 addTocart(id : number) {
  this.bookCart = this.bookService.getBookItemById(id);
  this.cart.cartItems.push(this.bookCart);
  return this.bookCart.name;
 }

 removeCartItem(item_id : number) {
   const item_index = this.cart.cartItems.findIndex(cartItem => cartItem.id == item_id);
   this.cart.cartItems.splice(item_index,1);

 }
  constructor(private bookService : BookserviceService) { }
}
