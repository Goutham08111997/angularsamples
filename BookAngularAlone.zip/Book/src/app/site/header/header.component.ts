import { Component, OnInit } from '@angular/core';
import {AuthService} from '../auth.service';
import {CartserviceService} from '../../shopping/cartservice.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {

  constructor(private router : Router, private cartService : CartserviceService , private authService : AuthService) { }

  isAuthenticated() {
    return this.authService.loggedIn;
  }
  getUsername()
 {
return this.authService.authenticatedUser.username;
 }  
 
 isAdmin() {
   return this.authService.isAdmin;
 }
 isCustomer() {
   return this.authService.isCustomer;
 }

 getUser() {

  return this.authService.authenticatedUser;
 }

 SignedOut() {
   this.authService.logOut();
   this.router.navigate([this.authService.redirectUrl]);
 }
  
 ngOnInit() {
  }

}
