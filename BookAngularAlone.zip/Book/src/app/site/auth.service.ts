import { Injectable } from '@angular/core';
import { users } from './users';
import { UserServiceService } from './user-service.service';
import { stringify } from 'querystring';


@Injectable({
  providedIn: 'root'
})
export class AuthService {

  loggedIn = false;
  isAdmin = false;
  isCustomer = false;
  user : users;
  redirectUrl = '/menu';
  redirectUrlLogin = '/login';
  authenticatedUser : users;
  authSource : string = null;
  //from userservice
  userList : users[] = [{
    username : 'Admin',
    firstname  :  'Admin',
    lastname : 'account',
    password : 'admin',
    role : 'Admin'
  },
  {
    username : 'Aswin',
    firstname  :  'aswin',
    lastname : 'kumar',
    password : 'a123',
    role : 'Customer'
  }];
 
  constructor(public userService : UserServiceService) { }

  login(username : string, password: string) : boolean {
    console.log("inside login")
    this.user = this.userService.authenticate(username, password);
    if(this.user != null && this.user.role == 'Admin') {
      this.loggedIn = true;
      this.authenticatedUser = this.user;
      this.isAdmin = true;
      this.isCustomer = false;
      // this.redirectUrl = '/food-item-info';
      return true;
    }
    else if(this.user != null && this.user.role == 'Customer') {
      this.loggedIn = true;
      this.authenticatedUser = this.user;
      this.isAdmin = false;
      this.isCustomer = true;
      // this.redirectUrl = '/menu';
      return true;
    }
    else {
      this.isCustomer = false;
      this.isAdmin = true;
    }

  }

  logOut() {
    this.redirectUrl = '/';
    this.loggedIn = false;
    this.isCustomer = false;
    this.isAdmin = false;
    
  }

  isUserAdmin()
 {
   return  this.isAdmin;
 }

 //from user service
 authenticate (username : string , password:string) {
  for(let authUser of this.userList) {
    if(username== authUser.username && password == authUser.password) {
      return authUser;
    }
  }
  return null;
}
//
}
