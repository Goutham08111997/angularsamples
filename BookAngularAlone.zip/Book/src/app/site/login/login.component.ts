import { Component, OnInit } from '@angular/core';
import { AuthService } from '../auth.service'
import { FormGroup } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import {NgForm} from '@angular/forms'


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  loginForm : FormGroup;
  username: string ="";
  password : string = "";
  authSource : string = null;
  authenticated: boolean = false;
  isLoginValid = true;
  invalidUser = false;
  invalidUserMsg : string;

  constructor(private authService : AuthService, private route : ActivatedRoute, private router: Router ) { }

  ngOnInit() {
    this.authSource = this.authService.authSource;
  }

  onSubmit(form : NgForm) {
    console.log("inside on submit")
    this.username = form.value.username;
    this.password = form.value.password;
    this.authenticated = this.authService.login(this.username,this.password);
    console.log(this.authenticated);
    if(this.authenticated) {
      this.router.navigate([this.authService.redirectUrl]);
    }else {
      this.invalidUser= true;
      this.invalidUserMsg = "Invalid Username and Password";
      
    }
  }

}
