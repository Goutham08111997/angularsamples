import { Injectable } from '@angular/core';
import { users } from './users';

@Injectable({
  providedIn: 'root'
})
export class UserServiceService {
  userList : users[] = [{
    username : 'Admin',
    firstname  :  'Admin',
    lastname : 'account',
    password : 'admin',
    role : 'Admin'
  },
  {
    username : 'Aswin',
    firstname  :  'aswin',
    lastname : 'kumar',
    password : 'a123',
    role : 'Customer'
  }];
addUser(user: users) {
  this.userList.push(user);
  console.log(this.userList);

}

getUser() : users[] {
  return this.userList;
}

authenticate (username : string , password:string) {
  for(let authUser of this.userList) {
    if(username== authUser.username && password == authUser.password) {
      return authUser;
    }
  }
  return null;
}
  constructor() { }
}
