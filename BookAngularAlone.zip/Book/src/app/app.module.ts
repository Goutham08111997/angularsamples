import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {RouterModule} from '@angular/router';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BookItemInfoComponent } from './book/book-item-info/book-item-info.component';
import { BookMenuComponent } from './book/book-menu/book-menu.component';
import { BookSearchComponent } from './book/book-search/book-search.component';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import { ShoppingCartComponent } from './shopping/shopping-cart/shopping-cart.component';
import { BookItemEditComponent } from './book/book-item-edit/book-item-edit.component';
import { SignupComponent } from './signup/signup.component';
import { LoginComponent } from './site/login/login.component';
import { HeaderComponent } from './site/header/header.component'

@NgModule({
  declarations: [
    AppComponent,
    BookItemInfoComponent,
    BookMenuComponent,
    BookSearchComponent,
    ShoppingCartComponent,
    BookItemEditComponent,
    SignupComponent,
    LoginComponent,
    HeaderComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    RouterModule,
    ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
