import { Injectable } from '@angular/core';
import {Book} from './book';
import { AuthService } from '../site/auth.service';

@Injectable({
  providedIn: 'root'
})
export class BookserviceService {
  bookFilter: Book[] = [];
  book :  Book[]= [{
    id: 101,
    name: "Java",
    price:99,
    active:true,
    dateOfPublications:new Date('03/15/2017'),
    category:'Programming',
    freeDelivery:true,
    url: '../assets/images/java.jpg'
    //url:'https://images.unsplash.com/photo-1528735602780-2552fd46c7af?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60'
  },
{id: 102,
  name: "C-Programming",
  price:129,
  active:false,
  dateOfPublications:new Date('12/23/2017'),
  category:'Programming',
  freeDelivery:true,
  url: '../assets/images/C-Program.jpg'
  //url:'https://images.unsplash.com/photo-1512152272829-e3139592d56f?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=500&q=60'

},{
  id: 103,
  name: "Database",
  price:149,
  active:true,
  dateOfPublications:new Date('08/21/2017'),
  category:'Database',
  freeDelivery:false,
  url: '../assets/images/database.jpg'
  //url:'https://images.unsplash.com/photo-1534308983496-4fabb1a015ee?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=500&q=60'
},{
  id: 104,
  name: "UI design",
  price:99,
  active:false,
  dateOfPublications:new Date('02/07/2017'),
  category:'Designing',
  freeDelivery:true,
  url: '../assets/images/designing.jpg'
  //url:'https://images.unsplash.com/photo-1526230427044-d092040d48dc?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=500&q=60'
},{
  id: 105,
  name: "C++Programming",
  price:32,
  active:true,
  dateOfPublications:new Date('02/11/2022'),
  category:'Programming',
  freeDelivery:true,
  url: '../assets/images/book1.jpg'
  //url:'https://images.unsplash.com/photo-1564355808539-22fda35bed7e?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=500&q=60'
},];
updateBook : Book[];
getAllBookItem () : Book[]
 {
   return this.book;

 }
 getBookItems(active:boolean, dateOfPublications:Date) : Book[]{
   this.bookFilter= this.book.filter(x=>x.active == active && x.dateOfPublications < dateOfPublications);
   return this.bookFilter;
 }
 
 search(searchKey : string): Book[] {
  if (this.authService.isAdmin) {
    this.bookFilter = this.book.filter(x => x.name.toLowerCase().indexOf(searchKey.toLowerCase()) !== -1)
  }
  else
      this.bookFilter= this.book.filter(x=>x.name.toLowerCase().indexOf(searchKey.toLowerCase())!==-1 && x.active == true && x.dateOfPublications < new Date()) ;
    return this.bookFilter;
  }
  getBookItemById(bookId:number):Book {
    for(let books of this.book) {
      if(books.id==bookId) {
        return books;
      }
    }return null;
  }

  getBookItemAdmin() : Book[] {
    return this.book;

  }

  updateBookItem(book : Book) {
    const bookIndex = this.book.findIndex(updateBook => updateBook.id == book.id);
    //console.log(bookIndex);
    this.book[bookIndex] = book;
  }

   constructor(private authService : AuthService) { }
}
