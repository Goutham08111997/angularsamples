import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { Book } from '../book';
import { BookserviceService } from '../bookservice.service';
import {AuthService} from '../../site/auth.service';

import { Router } from '@angular/router';
import { CartserviceService } from 'src/app/shopping/cartservice.service';

@Component({
  selector: 'app-book-item-info',
  templateUrl: './book-item-info.component.html',
  styleUrls: ['./book-item-info.component.css']
})
export class BookItemInfoComponent implements OnInit {
  @Input() menuList : Book[];
  @Output() addedToCart = new EventEmitter();
  isAdmin : boolean = true;
  isCustomer : boolean = this.authService.isCustomer;
  itemName : string;
  itemAdded = false;

  constructor(public bookservice: BookserviceService, public authService : AuthService, public router : Router, public cartService : CartserviceService) { }

  ngOnInit() {
    //this.menuList =  this.bookservice.getAllBookItem();
    if(this.isEditAllowed()) {
      this.menuList = this.bookservice.getBookItemAdmin();
    }
    else {
      this.menuList = this.bookservice.getBookItems(true, new Date());
    }
  }

  isEditAllowed() : boolean {
    return this.authService.isAdmin;
  }

  addToCart(id : number) {
    if(this.isCustomer) {
      this.itemName = this.cartService.addTocart(id);
      this.addedToCart.emit(id);
      this.itemAdded = true;
      setTimeout(() => {
        this.itemAdded = false;} , 1000
      );
      return false;
    }
    else {
      this.authService.authSource='cart';
      this.router.navigate([this.authService.redirectUrlLogin])
    }

  }

}
