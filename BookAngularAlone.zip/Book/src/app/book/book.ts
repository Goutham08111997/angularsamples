export interface Book {
    id: number;
    name: string;
    price:number;
    active:boolean;
    dateOfPublications:Date;
    category:string;
    freeDelivery:boolean;
    url:string;
}