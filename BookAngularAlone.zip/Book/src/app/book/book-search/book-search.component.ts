import { Component, OnInit } from '@angular/core';
import { Book } from '../book';
import { VirtualTimeScheduler } from 'rxjs';
import { BookserviceService } from '../bookservice.service';

@Component({
  selector: 'app-book-search',
  templateUrl: './book-search.component.html',
  styleUrls: ['./book-search.component.css']
})
export class BookSearchComponent implements OnInit {
  searchKey : string;
  bookSearch : Book[];
  search()
 {
   this.bookSearch =  this.bookService.search(this.searchKey);
 }  constructor(public bookService : BookserviceService) { }

  ngOnInit() {
  }

}
