import { Component, OnInit } from '@angular/core';
import { Book } from '../book';
import { BookserviceService} from '../bookservice.service'
import { ActivatedRoute } from '@angular/router';
import { FormGroup, FormControl, Validators } from '@angular/forms';



@Component({
  selector: 'app-book-item-edit',
  templateUrl: './book-item-edit.component.html',
  styleUrls: ['./book-item-edit.component.css']
})
export class BookItemEditComponent implements OnInit {
  book : Book;
  id : number;
  AllBook : Book[] = this.bookservice.getAllBookItem();
  editForm : FormGroup;
  fieldEdited = false;

  constructor(private route : ActivatedRoute, private bookservice : BookserviceService) { }

  ngOnInit() {
    const bookId =+ (this.route.snapshot.paramMap.get('id'));
    this.book = this.bookservice.getBookItemById(bookId);
    this.id = bookId;
    this.editForm = new FormGroup ({
      'title': new FormControl(this.book.name, [Validators.required, Validators.maxLength(100)]),
      'price': new FormControl(this.book.price, [Validators.required, Validators.pattern('^[0-9]+$')]),
      'category': new FormControl(this.book.category, [Validators.required]),
      'dateOfPublications': new FormControl(this.book.dateOfPublications, [Validators.required]),
      'active': new FormControl(this.book.active, [Validators.required]),
      'freeDelivery': new FormControl(this.book.freeDelivery, [Validators.required])
    }
    );

  }

  updateBookItem() : void {
    this.book.name=this.editForm.value.title;
    this.book.price =this.editForm.value.price;
    this.book.category = this.editForm.value.category;
    this.book.dateOfPublications =this.editForm.value.dateOfPublications;
    this.book.active =this.editForm.value.active;
    this.book.freeDelivery =this.editForm.value.freeDelivery;

    this.bookservice.updateBookItem(this.book);
    this.fieldEdited = true;
  }
  get title() { return this.editForm.get('title'); }
  get price() { return this.editForm.get('price'); }
  get category() { return this.editForm.get('category'); }



}
