import { Component, OnInit, Input } from '@angular/core';

import { Book } from '../book';
import { BookserviceService } from '../bookservice.service';
import { CartserviceService } from 'src/app/shopping/cartservice.service';

@Component({
  selector: 'app-book-menu',
  templateUrl: './book-menu.component.html',
  styleUrls: ['./book-menu.component.css']
})
export class BookMenuComponent implements OnInit {
@Input() menuList : Book[]
  constructor(public bookservice: BookserviceService, public cartservice : CartserviceService) { }
  addToCart(book:Book) {
  this.cartservice.addTocart(book.id);
  }
  ngOnInit() {
    this.menuList =  this.bookservice.getBookItems(true,new Date());
  }

}
