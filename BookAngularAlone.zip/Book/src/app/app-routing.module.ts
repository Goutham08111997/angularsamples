import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {BookSearchComponent} from './book/book-search/book-search.component';
import {ShoppingCartComponent} from './shopping/shopping-cart/shopping-cart.component';
import {BookItemInfoComponent} from './book/book-item-info/book-item-info.component';
import  {BookItemEditComponent} from './book/book-item-edit/book-item-edit.component';
import {SignupComponent} from './signup/signup.component';
import {LoginComponent} from './site/login/login.component'
import { AuthGuard } from './site/auth.guard';

const routes: Routes = [
  {
    path : 'menu', component : BookSearchComponent
  },
  {
    path : 'cart', component : ShoppingCartComponent,canActivate:[AuthGuard]
  },
  {
    path : 'book-item-info', component : BookItemInfoComponent
  },
  {
    path : 'book-item-edit/:id', component: BookItemEditComponent,canActivate:[AuthGuard]
  },
  {
    path : 'signup' , component : SignupComponent
  },
  {
    path : 'login' , component : LoginComponent
  }, 
  {
  path: '', redirectTo: 'menu', pathMatch: 'full' 
  }

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
