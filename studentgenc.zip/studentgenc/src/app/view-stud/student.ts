import { Skill } from './skill';
import { Department } from './department';

export interface Student {
    id: string;
    name: string;
    salary: number;
    permanent: boolean;
    department: Department;
    skills?: Skill[],
    dateOfBirth?: Date
}
