import { Component, OnInit } from '@angular/core';
import { Student } from './student';
import { UserAuthService } from '../Services/user-auth.service';

@Component({
  selector: 'app-view-stud',
  templateUrl: './view-stud.component.html',
  styleUrls: ['./view-stud.component.css']
})
export class ViewStudComponent {//implements OnInit {

  student: Student = {
    id: "1",
    name: "Rajesh",
    salary: 21000,
    permanent: true,
    department: {
      id: 1,
      name: "Mech"
    },
    skills: [
      { id: 1, name: "HTML" },
      { id: 2, name: "CSS" },
      { id: 3, name: "JavaScript" }
    ],
    dateOfBirth: new Date('04/21/2019')
  };

 /* constructor(private authService: UserAuthService) {
      this.authService.login();*/
   }

 /* ngOnInit() {    
  }
}*/
