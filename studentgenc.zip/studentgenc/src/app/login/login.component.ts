import { Component, OnInit } from '@angular/core';
import { UserAuthService } from '../Services/user-auth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  username: string;
  password: string;
  authenticationFailed;

  constructor(private authService: UserAuthService, private router: Router) { }

  ngOnInit() {
    this.authenticationFailed = false;
  }

  onSubmit() {
    if (this.username == 'admin' && this.password == "password") {
      this.authService.login();

      this.authenticationFailed = false;
      
      this.router.navigate(['student-list']);
    } else {
      this.authenticationFailed = true;
    }
  }

}
