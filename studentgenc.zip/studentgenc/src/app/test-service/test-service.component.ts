import { Component, OnInit } from '@angular/core';
import { StudentService } from '../Services/student.service';

@Component({
  selector: 'app-test-service',
  templateUrl: './test-service.component.html',
  styleUrls: ['./test-service.component.css']
})
export class TestServiceComponent implements OnInit {

  // serviceResponse: string;
  // constructor(private _studentService: StudentService) { }

   ngOnInit() {
   }

  // getAction() {
  //   this._studentService.getReqResUsers().subscribe(
  //     users => this.serviceResponse = JSON.stringify(users.data),
  //     error => console.log("error " + error)
  //   );
  // }

  // postAction() {
  //   this._studentService.postReqResUsers().subscribe(
  //     postResponse => {
  //       console.log("postResponse " + JSON.stringify(postResponse));
  //       this.serviceResponse = JSON.stringify(postResponse)
  //     },
  //     error => console.log("error " + error)
  //   );
  // }
}
