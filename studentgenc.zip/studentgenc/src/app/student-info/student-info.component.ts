import { Component, OnInit, Input } from '@angular/core';
import { Student } from '../view-stud/student';
import { Router } from '@angular/router';

@Component({
  selector: '[app-student-info]',
  templateUrl: './student-info.component.html',
  styleUrls: ['./student-info.component.css']
})
export class StudentInfoComponent implements OnInit {

  @Input() student: Student;
  
  constructor(private router: Router) { }

  ngOnInit() {
  }

  onClick(studentId : number){
    this.router.navigate(['/students', studentId]);
  }
}
