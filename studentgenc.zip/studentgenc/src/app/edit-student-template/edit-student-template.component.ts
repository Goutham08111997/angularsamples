import { Component, OnInit } from '@angular/core';
import { Student } from '../view-stud/student';
import { Department } from '../view-stud/department';

@Component({
  selector: 'app-edit-student-template',
  templateUrl: './edit-student-template.component.html',
  styleUrls: ['./edit-student-template.component.css']
})
export class EditStudentTemplateComponent implements OnInit {

  student: Student;
  departments : Department[];
  permanent: string;
  
  constructor() { }

  ngOnInit() {

    this.student = {
      id: "1",
      name: "Rajesh",
      salary: 10000,
      permanent: false,
      department: {
        id: 2,
        name: "Internal"
      },
      skills: [
        { id: 1, name: "HTML" },
        { id: 2, name: "CSS" },
        { id: 3, name: "JavaScript" }
      ],
      dateOfBirth: new Date('04/21/2019')
    };
    
    this.permanent = this.student.permanent == true ? "Yes" : "No";
    this.departments = [
      { id: 1, name: "Mech" },
      { id: 2, name: "Comp" },
      { id: 3, name: "ECE" }
    ];
  }

  onSubmit() {
    console.log(this.student);
  }

  departmentChange(target:any) {
    console.log(target);
  }
}
