import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ViewStudComponent } from './view-stud/view-stud.component'
import { EditStudComponent } from './edit-stud/edit-stud.component'
import { EditStudentTemplateComponent } from './edit-student-template/edit-student-template.component';
import { StudentListComponent } from './student-list/student-list.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { AuthGuardService } from './auth-guard.service';
import { LoginComponent } from './login/login.component';
import { TestServiceComponent } from './test-service/test-service.component';


const routes: Routes = [
  { path: 'view-stud', component: ViewStudComponent },
  { path: 'edit-stud/:id', component: EditStudComponent, canActivate: [AuthGuardService] },
  { path: 'edit-stud-template', component: EditStudentTemplateComponent },
  { path: 'student-list', component: StudentListComponent },
  { path: 'notfound', component: PageNotFoundComponent },
  { path: 'login', component: LoginComponent },
  { path: 'test-service', component: TestServiceComponent },
  { path: '', redirectTo: 'login', pathMatch: 'full' },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
