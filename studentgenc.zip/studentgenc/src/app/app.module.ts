import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HttpClientModule } from '@angular/common/http';

import { ViewStudComponent } from './view-stud/view-stud.component';
import { EditStudComponent } from './edit-stud/edit-stud.component';
import { EditStudentTemplateComponent } from './edit-student-template/edit-student-template.component';
import { StudentListComponent } from './student-list/student-list.component';
import { StudentInfoComponent } from './student-info/student-info.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { LoginComponent } from './login/login.component';
import { TestServiceComponent } from './test-service/test-service.component';

@NgModule({
  declarations: [
    AppComponent,
    ViewStudComponent,
    EditStudComponent,
    EditStudentTemplateComponent,
    StudentListComponent,
    StudentInfoComponent,
    PageNotFoundComponent,
    LoginComponent,
    TestServiceComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    AppRoutingModule,    
    ReactiveFormsModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
