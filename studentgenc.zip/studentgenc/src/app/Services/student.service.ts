import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Student } from '../view-stud/student';

@Injectable({
  providedIn: 'root'
})
export class StudentService {

  private studloyeeApiUrl = '';
  //private reqresBaseUrl = 'https://reqres.in/';

  private request: JSON;

  constructor(private _httpClient: HttpClient) {
    /*this.getReqResUsers().subscribe(
      users => console.log("users data " + users.data),
      error => console.log("error " + error)
    );

    this.postReqResUsers().subscribe(
      postResponse => console.log("postResponse " + JSON.stringify(postResponse)),
      error => console.log("error " + error)
    );*/
  }

  /*getStudents(): Observable<Student[]> {
      return this._httpClient.get<Student[]>(this.studloyeeApiUrl);
  }

  /*getReqResUsers(): Observable<any> {
    return this._httpClient.get(this.reqresBaseUrl + "api/users?page=2");
  }

  postReqResUsers(): Observable<any> {
    this.request = JSON.parse('{ "name": "morpheus", "job": "leader"}');
    let headers = new HttpHeaders({
      'Content-Type': 'application/json',
    });
    let options = { headers: headers };
    return this._httpClient.post(this.reqresBaseUrl + 'api/users', this.request, options);
  }*/

  getStudents1(): Student[] {
    return [{
      "id": "1",
      "name": "Rajesh",
      "salary": 20000,
      "permanent": true,
      "dateOfBirth": new Date(),
      "department": null,
      "skills": null
    },
    {
      "id": "2",
      "name": "RamKumar",
      "salary": 21000,
      "permanent": false,
      "dateOfBirth": new Date(),
      "department": null,
      "skills": null
    },
    {
      "id": "3",
      "name": "Karthi",
      "salary": 21000,
      "permanent": false,
      "dateOfBirth": new Date(),
      "department": null,
      "skills": null
    },
    {
      "id": "4",
      "name": "Kavitha",
      "salary": 22000,
      "permanent": false,
      "dateOfBirth": new Date(),
      "department": null,
      "skills": null
    }];

  }
}