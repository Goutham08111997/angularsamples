import { Component, OnInit } from '@angular/core';
import { Student } from '../view-stud/student';
import { StudentService } from '../Services/student.service';

@Component({
  selector: 'app-student-list',
  templateUrl: './student-list.component.html',
  styleUrls: ['./student-list.component.css']
})
export class StudentListComponent implements OnInit {

  students : Student[];
  filteredStudents : Student[];
  searchKey: string;

  constructor(private _studService : StudentService) { }

  ngOnInit() {
    this.students = this._studService.getStudents1();
    this.filteredStudents = this.students;
  }

  search() {
    let filter = this.searchKey.toLocaleLowerCase();
    this.filteredStudents = this.students.filter(
      (stud: Student) => stud.name.toLocaleLowerCase().indexOf(filter) != -1
    );
  }
}
