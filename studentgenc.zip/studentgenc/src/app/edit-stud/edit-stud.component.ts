import { Component, OnInit } from '@angular/core';
import { FormGroup, Validators, FormControl } from '@angular/forms';
import { Student } from '../view-stud/student';
import { Department } from '../view-stud/department';
import { ActivatedRoute } from "@angular/router";

@Component({
  selector: 'app-edit-stud',
  templateUrl: './edit-stud.component.html',
  styleUrls: ['./edit-stud.component.css']
})
export class EditStudComponent implements OnInit {
  studForm: FormGroup;
  student: Student = {
    id: "1",
    name: "Rajesh",
    salary: 10000,
    permanent: false,
    department: {
      id: 3,
      name: "ECE"
    },
    skills: [
      { id: 1, name: "HTML" },
      { id: 2, name: "CSS" },
      { id: 3, name: "JavaScript" }
    ],
    dateOfBirth: new Date('04/21/2019')
  };

  departments: Department[];

  constructor(private route : ActivatedRoute) { }

  ngOnInit() {

    const param = this.route.snapshot.paramMap.get('id');
    
    console.log('Id: ' + param);

    this.studForm = new FormGroup({
      'id': new FormControl(this.student.id),
      'name': new FormControl(this.student.name, [
        Validators.required,
        Validators.minLength(4),
        Validators.maxLength(20)
      ]),
      'salary': new FormControl(this.student.salary, [
        Validators.required
      ]),
      'department': new FormGroup({
        id: new FormControl(this.student.department.id),
        name: new FormControl(this.student.department.name)
      }),
      'permanent': new FormControl(this.student.permanent == true ? "Yes" : "No", [
        Validators.required
      ]),
    });

    this.departments = [
      { id: 1, name: "Mech" },
      { id: 2, name: "Comp" },
      { id: 3, name: "ECE" }
    ];    
  }

  get salary() { return this.studForm.get('salary'); }
  get name() { return this.studForm.get('name'); }
  get department() { return this.studForm.get('department'); }
  get permanent() { return this.studForm.get('permanent'); }

  onSubmit() {
    if (this.studForm.valid) {
      console.log("Form Submitted!");
      console.log(this.studForm.value);
    }
  }

}
