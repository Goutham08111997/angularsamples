package com.cognizant.book.exception;

import java.util.Date;

public class MyError {
	String errorDescription;
	String errorCode;
	Date date;
	public String getErrorDescription() {
		return errorDescription;
	}
	public void setErrorDescription(String errorDescription) {
		this.errorDescription = errorDescription;
	}
	public String getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	public MyError(String errorDescription, String errorCode, Date date) {
		super();
		this.errorDescription = errorDescription;
		this.errorCode = errorCode;
		this.date = date;
	}
	
	
}
