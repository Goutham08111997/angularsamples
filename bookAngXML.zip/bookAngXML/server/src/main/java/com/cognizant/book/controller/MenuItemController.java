package com.cognizant.book.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cognizant.book.BookApplication;
import com.cognizant.book.model.MenuItem;
import com.cognizant.book.service.MenuItemService;

@RestController
@RequestMapping("/book")
public class MenuItemController {
	private static final Logger LOGGER = LoggerFactory.getLogger(BookApplication.class);
	int value=2;
	@Autowired
	MenuItemService menuItemService;
	
	@Autowired
	InMemoryUserDetailsManager inMemoryUserDetailsManager;
	
	@GetMapping("/menu-items")
	public List<MenuItem> getAllMenuItems(){
		LOGGER.info("Start");
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		String user = authentication.getName();
		if(user!="anonymousUser") {
		UserDetails userDetails = inMemoryUserDetailsManager.loadUserByUsername(user);
		String role = userDetails.getAuthorities().toArray()[0].toString();
		
		if(role.contentEquals("ROLE_ADMIN")) {
			LOGGER.info("End");
			return menuItemService.getMenuItemListAdmin();
		} else {
			LOGGER.info("End");
			return menuItemService.getMenuItemListCustomer();
		}
		} else {
			LOGGER.info("End");
			return menuItemService.getMenuItemListCustomer();
		}
	}

	/*
	 * @PostMapping("/menu-items") public MenuItem addMenuItem(@RequestBody @Valid
	 * MenuItem theMenuItem) { return this.MenuItemDao.addMenuItem(theMenuItem); }
	 */
	@PutMapping("/menu-items")
	public void updateMenuItem(@RequestBody MenuItem theMenuItem) {
		LOGGER.info("Start");
		this.menuItemService.updateMenuItem(theMenuItem);
		LOGGER.info("End");
	}

	/*
	 * @DeleteMapping("/menu-items/{id}") public void deleteMenuItem(@PathVariable
	 * int id) throws MenuItemNotFoundException {
	 * this.MenuItemDao.deleteMenuItem(id); }
	 */
	@GetMapping("/menu-items/{id}")
	public MenuItem getMenuItem(@PathVariable int id) {
		LOGGER.info("Start");
		LOGGER.info("End");
		return this.menuItemService.getMenuItem(id);
	}
}
