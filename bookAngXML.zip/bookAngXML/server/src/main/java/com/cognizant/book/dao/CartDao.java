package com.cognizant.book.dao;


import com.cognizant.book.exception.CartEmptyException;
import com.cognizant.book.model.Cart;

public interface CartDao {

	void addCartItem(String user, long menuItemId);

	Cart getAllCartItems(String user) throws CartEmptyException;

	void removeCartItem(String user, long menuItemList);

}
