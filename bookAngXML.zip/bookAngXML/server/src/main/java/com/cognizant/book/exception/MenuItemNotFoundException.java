package com.cognizant.book.exception;

public class MenuItemNotFoundException extends Exception {

	public MenuItemNotFoundException(String string) {
		
	}

}
