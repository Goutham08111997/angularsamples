package com.cognizant.book.dao;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Repository;

import com.cognizant.book.BookApplication;
import com.cognizant.book.model.MenuItem;

@Repository
public class MenuItemDaoCollectionImpl implements MenuItemDao {
	private static final Logger LOGGER = LoggerFactory.getLogger(BookApplication.class);
	static List<MenuItem> menuItemList;

	public MenuItemDaoCollectionImpl() {
		ApplicationContext context = new ClassPathXmlApplicationContext("book.xml");
		menuItemList = context.getBean("menuItemList", ArrayList.class);

	}

	@Override
	public List<MenuItem> getMenuItemListAdmin() {
		LOGGER.info("Start");
		LOGGER.info("End");
		return menuItemList;
	}

	@Override
	public List<MenuItem> getMenuItemListCustomer() {
		LOGGER.info("Start");
		List<MenuItem> menuList = new ArrayList<MenuItem>();
		Iterator itr = (Iterator) menuItemList.iterator();
		while (itr.hasNext()) {
			MenuItem menuItem = (MenuItem) itr.next();
			Date day = menuItem.getDateOfPublication();
			Date today = Calendar.getInstance().getTime();
			if ((day.compareTo(today) <= 0) && (menuItem.isActive() == true)) {
				menuList.add(menuItem);
			}
		}
		LOGGER.info("End");
		return menuList;
	}

	@Override
	public void updateMenuItem(MenuItem menuItem) {
		LOGGER.info("Start");
		// TODO Auto-generated method stub
		for (int i = 0; i < menuItemList.size(); i++) {
			if (menuItem.getId() == menuItemList.get(i).getId()) {
				menuItemList.set(i, menuItem);
			}
		}
		LOGGER.info("End");
	}

	@Override
	public MenuItem getMenuItem(long menuItemId) {
		LOGGER.info("Start");
		MenuItem menu = null;
		for (int i = 0; i < menuItemList.size(); i++) {
			if (menuItemId == menuItemList.get(i).getId()) {
				menu = menuItemList.get(i);
			}
		}
		LOGGER.info("End");
		return menu;
	}
}