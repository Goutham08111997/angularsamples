package com.cognizant.book.exception;

public class CartEmptyException extends Exception {
	String message;

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public CartEmptyException(String message) {
		super();
		this.message = message;
	}
	
}
