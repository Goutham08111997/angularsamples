package com.cognizant.book.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.book.BookApplication;
import com.cognizant.book.dao.CartDao;
import com.cognizant.book.exception.CartEmptyException;
import com.cognizant.book.model.Cart;

@Service
public class CartServiceImpl implements CartService{
	private static final Logger LOGGER = LoggerFactory.getLogger(BookApplication.class);
	@Autowired
	CartDao cartDao;
	
	@Override
	public void addCartItem(String user, long menuItemId) {
		LOGGER.info("Start");
		cartDao.addCartItem(user, menuItemId);
		LOGGER.info("End");
	}

	@Override
	public Cart getAllCartItems(String user) throws CartEmptyException{
		LOGGER.info("Start");
		LOGGER.info("End");
		return cartDao.getAllCartItems(user);
	}

	@Override
	public void removeCartItem(String user, long menuItemid) {
		LOGGER.info("Start");
		cartDao.removeCartItem(user, menuItemid);
		LOGGER.info("End");
	}

}
