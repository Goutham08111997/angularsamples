package com.cognizant.book.service;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.book.BookApplication;
import com.cognizant.book.dao.MenuItemDao;
import com.cognizant.book.model.MenuItem;

@Service
public class MenuItemService {
	private static final Logger LOGGER = LoggerFactory.getLogger(BookApplication.class);
	
	@Autowired
	MenuItemDao menuItemDao;
	
	public List<MenuItem> getMenuItemListAdmin(){
		LOGGER.info("Start");
		LOGGER.info("End");
		return this.menuItemDao.getMenuItemListAdmin();
	}
	public List<MenuItem> getMenuItemListCustomer(){
		LOGGER.info("Start");
		LOGGER.info("End");
		return this.menuItemDao.getMenuItemListCustomer();
	}
	/*
	 * public MenuItem addMenuItem(@RequestBody @Valid MenuItem theMenuItem) {
	 * return this.MenuItemDao.addMenuItem(theMenuItem); }
	 */
	/*
	 * public MenuItem updateMenuItem(@RequestBody @Valid MenuItem theMenuItem) {
	 * return this.MenuItemDao.updateMenuItem(theMenuItem); }
	 * 
	 * public void deleteMenuItem(@PathVariable int id) throws
	 * MenuItemNotFoundException { this.MenuItemDao.deleteMenuItem(id); }
	 */
	public void updateMenuItem(MenuItem theMenuItem) {
		LOGGER.info("Start");
		this.menuItemDao.updateMenuItem(theMenuItem);
		LOGGER.info("End");
	}
	
	public MenuItem getMenuItem(int id) {
		LOGGER.info("Start");
		LOGGER.info("End");
		return this.menuItemDao.getMenuItem(id);
	}

}
