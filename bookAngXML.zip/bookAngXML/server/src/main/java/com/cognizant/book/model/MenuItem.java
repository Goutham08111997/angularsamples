package com.cognizant.book.model;

import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.cognizant.book.BookApplication;

public class MenuItem {
	private static final Logger LOGGER = LoggerFactory.getLogger(BookApplication.class);
	long id;
	String name;
	float price;
	@Override
	public String toString() {
		return "MenuItem [id=" + id + ", name=" + name + ", price=" + price + ", active=" + active + ", dateOfPublication="
				+ dateOfPublication + ", category=" + category + ", freeDelivery=" + freeDelivery + ", image=" + image + "]";
	}
	boolean active;
	Date dateOfPublication;
	String category;
	boolean freeDelivery;
	String image;
	
	public MenuItem() {
		super();
		LOGGER.info("Start");
		LOGGER.info("End");
	}
	public long getId() {
		LOGGER.info("Start");
		LOGGER.info("End");
		return id;
	}
	public void setId(long id) {
		LOGGER.info("Start");
		this.id = id;
		LOGGER.info("End");
	}
	public String getName() {
		LOGGER.info("Start");
		LOGGER.info("End");
		return name;
	}
	public void setName(String name) {
		LOGGER.info("Start");
		LOGGER.info("End");
		this.name = name;
	}
	public float getPrice() {
		LOGGER.info("Start");
		LOGGER.info("End");
		return price;
	}
	public void setPrice(float price) {
		LOGGER.info("Start");
		this.price = price;
		LOGGER.info("End");
	}
	public boolean isActive() {
		LOGGER.info("Start");
		LOGGER.info("End");
		return active;
	}
	public void setActive(boolean active) {
		LOGGER.info("Start");
		this.active = active;
		LOGGER.info("End");
	}
	public Date getDateOfPublication() {
		LOGGER.info("Start");
		LOGGER.info("End");
		return dateOfPublication;
	}
	public void setDateOfPublication(Date dateOfPublication) {
		LOGGER.info("Start");
		this.dateOfPublication = dateOfPublication;
		LOGGER.info("End");
	}
	public String getCategory() {
		LOGGER.info("Start");
		LOGGER.info("End");
		return category;
	}
	public void setCategory(String category) {
		LOGGER.info("Start");
		this.category = category;
		LOGGER.info("End");
	}
	public boolean isFreeDelivery() {
		LOGGER.info("Start");
		LOGGER.info("End");
		return freeDelivery;
	}
	public void setFreeDelivery(boolean freeDelivery) {
		LOGGER.info("Start");
		this.freeDelivery = freeDelivery;
		LOGGER.info("End");
	}
	public MenuItem(long id, String name, float price, boolean active, Date date, String category,
			boolean freeDelivery, String image) {
		super();
		LOGGER.info("Start");
		this.id = id;
		this.name = name;
		this.price = price;
		this.active = active;
		this.dateOfPublication = date;
		this.category = category;
		this.freeDelivery = freeDelivery;
		this.image = image;
		LOGGER.info("End");
	}
	public String getImage() {
		return image;
	}
	public void setImage(String image) {
		this.image = image;
	}
}
