package com.cognizant.book.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import com.cognizant.book.BookApplication;
import com.cognizant.book.exception.CartEmptyException;
import com.cognizant.book.model.Cart;
import com.cognizant.book.model.MenuItem;

@Repository
public class CartDaoCollectionImpl implements CartDao{
	private static final Logger LOGGER = LoggerFactory.getLogger(BookApplication.class);

	private static Map<String, Cart> userCarts = null;

	public CartDaoCollectionImpl() {
		if (userCarts == null) {
			userCarts = new HashMap<String, Cart>();
		}
	}
	
	@Override
	public void addCartItem(String user, long menuItemId) {
		LOGGER.info("Start");
		MenuItemDao menuItemDao = new MenuItemDaoCollectionImpl();
		MenuItem menuItem = menuItemDao.getMenuItem(menuItemId);

		if (!userCarts.containsKey(user)) {
			userCarts.put(user, new Cart(new ArrayList<MenuItem>(), 0.0));
		}
		Cart cartItem = userCarts.get(user);
		cartItem.getMenuItemList().add(menuItem);
		LOGGER.info("End");
	}

	@Override
	public Cart getAllCartItems(String user) throws CartEmptyException {
		LOGGER.info("Start");
		List<MenuItem> menuItemList = null;
		Cart cartItem = null;
		double total = 0.0;
		
		if(userCarts.isEmpty()) {
			LOGGER.info("End");
			throw new CartEmptyException("Cart is Empty");
		}else if (userCarts.containsKey(user)) {
			cartItem = userCarts.get(user);
			menuItemList = cartItem.getMenuItemList();

			if (menuItemList.isEmpty()) {
				LOGGER.info("End");
				throw new CartEmptyException("Cart Empty");
			} else {
				for (MenuItem item : menuItemList) {
					total += item.getPrice();
				}
				cartItem.setTotal(total);
			}
		}
		LOGGER.info("End");
		return cartItem;
	}

	@Override
	public void removeCartItem(String user, long menuItemId) {
		LOGGER.info("Start");
		if (userCarts.containsKey(user)) {
			Cart cartItem = userCarts.get(user);
			List<MenuItem> menuItems = cartItem.getMenuItemList();

			for (int i = 0; i < menuItems.size(); i++) {
				if (menuItems.get(i).getId() == menuItemId) {
					menuItems.remove(i);
					break;
				}
			}

		}
		LOGGER.info("End");
	}

}
