package com.cognizant.book.model;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.cognizant.book.BookApplication;

public class Users {
	private static final Logger LOGGER = LoggerFactory.getLogger(BookApplication.class);
	String userName;
	String firstName;
	String lastName;
	String password;
	public String getUserName() {
		LOGGER.info("Start");
		LOGGER.info("End");
		return userName;
	}
	public void setUserName(String userName) {
		LOGGER.info("Start");
		this.userName = userName;
		LOGGER.info("End");
	}
	public String getFirstName() {
		LOGGER.info("Start");
		LOGGER.info("End");
		return firstName;
	}
	public void setFirstName(String firstName) {
		LOGGER.info("Start");
		this.firstName = firstName;
		LOGGER.info("End");
	}
	public String getLastName() {
		LOGGER.info("Start");
		LOGGER.info("End");
		return lastName;
	}
	public void setLastName(String lastName) {
		LOGGER.info("Start");
		this.lastName = lastName;
		LOGGER.info("Start");
	}
	public String getPassword() {
		LOGGER.info("Start");
		LOGGER.info("End");
		return password;
	}
	public void setPassword(String password) {
		LOGGER.info("Start");
		this.password = password;
		LOGGER.info("End");
	}
	public Users(String userName, String firstName, String lastName, String password) {
		super();
		LOGGER.info("Start");
		this.userName = userName;
		this.firstName = firstName;
		this.lastName = lastName;
		this.password = password;
		LOGGER.info("End");
	}
	

}
