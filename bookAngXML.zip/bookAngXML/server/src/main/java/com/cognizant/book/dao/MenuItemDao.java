package com.cognizant.book.dao;

import java.util.List;

import com.cognizant.book.model.MenuItem;

public interface MenuItemDao {
	public List<MenuItem> getMenuItemListAdmin();
	public List<MenuItem> getMenuItemListCustomer();
	public void updateMenuItem(MenuItem menuItem);
	public MenuItem getMenuItem(long menuItemId);

}
