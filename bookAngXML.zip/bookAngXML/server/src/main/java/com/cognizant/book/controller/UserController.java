package com.cognizant.book.controller;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cognizant.book.BookApplication;
import com.cognizant.book.exception.UserAlreadyExistsException;
import com.cognizant.book.model.Users;

@RestController
@RequestMapping("/book")
public class UserController {
	private static final Logger LOGGER = LoggerFactory.getLogger(BookApplication.class);
	@Autowired
	InMemoryUserDetailsManager inMemoryUserDetailsManager;
	
	@PostMapping("/users")
	public void signup(@RequestBody @Valid Users users) throws UserAlreadyExistsException{
		LOGGER.info("Start");
		boolean flag = inMemoryUserDetailsManager.userExists(users.getUserName());
		if(flag) {
			LOGGER.info("End");
			throw new UserAlreadyExistsException("User Exists");
		}
		else {
			inMemoryUserDetailsManager.createUser(User.withUsername(users.getUserName())
									  .password(passwordEncoder()
									  .encode(users.getPassword()))
									  .roles("USER").build());
			LOGGER.info("End");
		}
	}
	public PasswordEncoder passwordEncoder() {
		LOGGER.info("Start");
		LOGGER.info("End");
		return new BCryptPasswordEncoder();
	}
}
