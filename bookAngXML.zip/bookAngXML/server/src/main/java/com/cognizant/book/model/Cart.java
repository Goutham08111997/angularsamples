package com.cognizant.book.model;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.cognizant.book.BookApplication;

public class Cart {
	private static final Logger LOGGER = LoggerFactory.getLogger(BookApplication.class);
	private List<MenuItem> menuItemList;
	private double total;

	public List<MenuItem> getMenuItemList() {
		LOGGER.info("Start");
		LOGGER.info("End");
		return menuItemList;
	}

	public void setMenuItemList(List<MenuItem> menuItemList) {
		LOGGER.info("Start");
		this.menuItemList = menuItemList;
		LOGGER.info("End");
	}

	public double getTotal() {
		LOGGER.info("Start");
		LOGGER.info("End");
		return total;
	}

	public void setTotal(double total) {
		LOGGER.info("Start");
		this.total = total;
		LOGGER.info("End");
	}

	public Cart(List<MenuItem> menuItemList, double total) {
		super();
		LOGGER.info("Start");
		this.menuItemList = menuItemList;
		this.total = total;
		LOGGER.info("End");
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((menuItemList == null) ? 0 : menuItemList.hashCode());
		long temp;
		temp = Double.doubleToLongBits(total);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Cart other = (Cart) obj;
		if (menuItemList == null) {
			if (other.menuItemList != null)
				return false;
		} else if (!menuItemList.equals(other.menuItemList))
			return false;
		if (Double.doubleToLongBits(total) != Double.doubleToLongBits(other.total))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Cart [menuItemList=" + menuItemList + ", total=" + total + "]";
	}

}
