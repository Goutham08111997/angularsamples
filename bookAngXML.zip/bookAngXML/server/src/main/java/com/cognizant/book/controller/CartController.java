package com.cognizant.book.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cognizant.book.BookApplication;
import com.cognizant.book.exception.CartEmptyException;
import com.cognizant.book.model.Cart;
import com.cognizant.book.service.CartService;

@RestController
@RequestMapping("/book")
public class CartController {
	private static final Logger LOGGER = LoggerFactory.getLogger(BookApplication.class);
	@Autowired
	CartService cartService;
	
	@PostMapping("/cart-items/{user}/{menuItemId}")
	public void addCartItem(@PathVariable String user,@PathVariable long menuItemId) {
		LOGGER.info("Start");
		cartService.addCartItem(user,menuItemId);
		LOGGER.info("End");
	}
	
	@GetMapping("/cart-items/{users}")
	public Cart getAllCartItems(@PathVariable String users) throws CartEmptyException {
		LOGGER.info("Start");
		LOGGER.info("End");
		return cartService.getAllCartItems(users);
	}
	
	@DeleteMapping("/cart-items/{user}/{menuItemId}")
	public void removeCartItem(@PathVariable String user,@PathVariable long menuItemId) {
		LOGGER.info("Start");
		cartService.removeCartItem(user, menuItemId);
		LOGGER.info("End");
	}
}
