package com.cognizant.book.service;

import com.cognizant.book.exception.CartEmptyException;
import com.cognizant.book.model.Cart;

public interface CartService {
	public void addCartItem(String user, long menuItemId);
	public Cart getAllCartItems(String user) throws CartEmptyException;
	public void removeCartItem(String user, long menuItemid);
}
