import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-book-edit-success',
  templateUrl: './book-edit-success.component.html',
  styleUrls: ['./book-edit-success.component.css']
})
export class BookEditSuccessComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
