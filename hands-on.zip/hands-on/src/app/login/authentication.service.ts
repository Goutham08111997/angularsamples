// import { Injectable } from '@angular/core';
// import { Observable } from 'rxjs';
// import { HttpHeaders, HttpClient } from '@angular/common/http';

// @Injectable({
//   providedIn: 'root'
// })
// export class AuthenticationService {

//   private authenticationApiUrl = 'http://localhost:8083/authentication-service/authenticate';
//   private token: string;
//   constructor(private _httpClient: HttpClient) { }
//   authenticate(user: string, password: string): Observable<any> {
//     const credentials = btoa(user + ':' + password);
//     let headers = new HttpHeaders();
//     headers = headers.set('Authorization', 'Basic ' + credentials);
//     return this._httpClient.get(this.authenticationApiUrl, { headers })
//   }
//   public setToken(token: string) {
//     this.token = token;
//   }
//   public getToken() {
//     return this.token;
//   }
// }
