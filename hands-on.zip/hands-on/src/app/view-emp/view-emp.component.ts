import { Component, OnInit } from '@angular/core';
import { Employee } from './employee';
import { UserAuthService } from '../Services/user-auth.service';

@Component({
  selector: 'app-view-emp',
  templateUrl: './view-emp.component.html',
  styleUrls: ['./view-emp.component.css']
})
export class ViewEmpComponent implements OnInit {

  employee: Employee = {
    id: "3",
    name: "John",
    salary: 10000,
    permanent: true,
    department: {
      id: 1,
      name: "Payroll"
    },
    skills: [
      { id: 1, name: "HTML" },
      { id: 2, name: "CSS" },
      { id: 3, name: "JavaScript" }
    ],
    dateOfBirth: new Date('04/21/2019')
  };

  constructor(private authService: UserAuthService) {
      this.authService.login();
   }

  ngOnInit() {    
  }
}
