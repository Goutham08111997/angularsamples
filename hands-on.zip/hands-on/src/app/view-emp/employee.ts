import { Skill } from './skill';
import { Department } from './department';

export interface Employee {
    id: string;
    name: string;
    salary: number;
    permanent: boolean;
    department: Department;
    skills?: Skill[],
    dateOfBirth?: Date
}
