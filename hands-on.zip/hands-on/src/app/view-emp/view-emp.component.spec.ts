import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewEmpComponent } from './view-emp.component';

describe('ViewEmpComponent', () => {
  let component: ViewEmpComponent;
  let fixture: ComponentFixture<ViewEmpComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ViewEmpComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewEmpComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should check for Employee object exists', ()=>{
    expect(component.employee).toBeTruthy();
  });

  it('should check department name with model and html element', () => {
    const compiled = fixture.debugElement.nativeElement;
    expect(compiled.querySelector('#departmentName').textContent).toBe(component.employee.department.name);
  });

});
