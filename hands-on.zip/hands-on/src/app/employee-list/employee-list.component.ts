import { Component, OnInit } from '@angular/core';
import { Employee } from '../view-emp/employee';
import { EmployeeService } from '../Services/employee.service';

@Component({
  selector: 'app-employee-list',
  templateUrl: './employee-list.component.html',
  styleUrls: ['./employee-list.component.css']
})
export class EmployeeListComponent implements OnInit {

  employees : Employee[];
  filteredEmployees : Employee[];
  searchKey: string;

  constructor(private _empService : EmployeeService) { }

  ngOnInit() {
    this.employees = this._empService.getEmployees1();
    this.filteredEmployees = this.employees;
  }

  search() {
    let filter = this.searchKey.toLocaleLowerCase();
    this.filteredEmployees = this.employees.filter(
      (emp: Employee) => emp.name.toLocaleLowerCase().indexOf(filter) != -1
    );
  }
}
