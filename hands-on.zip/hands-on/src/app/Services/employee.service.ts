import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Employee } from '../view-emp/employee';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {

  //private employeeApiUrl = '';
  //private reqresBaseUrl = 'https://reqres.in/';

  //private request: JSON;

  constructor(private _httpClient: HttpClient) {
    /*this.getReqResUsers().subscribe(
      users => console.log("users data " + users.data),
      error => console.log("error " + error)
    )

    this.postReqResUsers().subscribe(
      postResponse => console.log("postResponse " + JSON.stringify(postResponse)),
      error => console.log("error " + error)
    );*/
  }

  /*getEmployees(): Observable<Employee[]> {
      return this._httpClient.get<Employee[]>(this.employeeApiUrl);
  }*/
/*
  getReqResUsers(): Observable<any> {
    return this._httpClient.get(this.reqresBaseUrl + "api/users?page=2");
  }

  
  postReqResUsers(): Observable<any> {
    this.request = JSON.parse('{ "name": "morpheus", "job": "leader"}');
    let headers = new HttpHeaders({
      'Content-Type': 'application/json',
    });
    let options = { headers: headers };
    return this._httpClient.post(this.reqresBaseUrl + 'api/users', this.request, options);
  }*/

  getEmployees1(): Employee[] {
    return [{
      "id": "1",
      "name": "John",
      "salary": 10000,
      "permanent": true,
      "dateOfBirth": new Date(),
      "department": null,
      "skills": null
    },
    {
      "id": "2",
      "name": "Smith",
      "salary": 5000,
      "permanent": false,
      "dateOfBirth": new Date(),
      "department": null,
      "skills": null
    },
    {
      "id": "3",
      "name": "Mark",
      "salary": 5000,
      "permanent": false,
      "dateOfBirth": new Date(),
      "department": null,
      "skills": null
    },
    {
      "id": "4",
      "name": "Mary",
      "salary": 5000,
      "permanent": false,
      "dateOfBirth": new Date(),
      "department": null,
      "skills": null
    }];

  }
}