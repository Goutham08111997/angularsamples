// import { Component, OnInit } from '@angular/core';
// import { ActivatedRoute } from "@angular/router";
// import { FormControl, FormGroup, Validators } from '@angular/forms';
// import { Employee } from '../view-emp/employee';
// import { Department } from '../view-emp/department';
// import { EmployeeService } from '../employee.service';
// import { DepartmentService } from '../department.service';
// import { Observable } from 'rxjs';
// import { tap } from 'rxjs/operators'

// @Component({
//   selector: 'app-edit-emp-reactive',
//   templateUrl: './edit-emp-reactive.component.html',
//   styleUrls: ['./edit-emp-reactive.component.css']
// })
// export class EditEmpReactiveComponent implements OnInit {

//   employee: Observable<Employee>;
//   departments: Department[];
//   empForm: FormGroup;
//   empId: string;
//   error: string;
//   updatedEmployee: Employee;
//   constructor(private route: ActivatedRoute, private _employeeService: EmployeeService, private _departmentService: DepartmentService) {
//     this.empId = this.route.snapshot.paramMap.get('id');
//     // this._employeeService.getEmployee(this.empId).subscribe((employee: Employee) => {
//     //   this.employee = employee;
//     //   if (employee) {
//     //   }
//     // });
//     // this.employee = {
//     //   id: null,
//     //   name: '',
//     //   salary: null,
//     //   permanent: null,
//     //   department: {
//     //     id: null,
//     //     name: ''
//     //   },
//     //   skills: null,
//     //   dateOfBirth: null
//     // };
//     // this.departments = [{
//     //   id: null,
//     //   name: ''
//     // }];
//     // console.log(employeeId);
//   }

//   ngOnInit() {
//     // this.employee = {
//     //   id: 3,
//     //   name: 'John',
//     //   salary: 10000,
//     //   permanent: true,
//     //   department: {
//     //     id: 1,
//     //     name: 'Payroll'
//     //   },
//     //   skills: [
//     //     { id: 1, name: 'HTML' },
//     //     { id: 2, name: 'CSS' },
//     //     { id: 3, name: 'JavaScript' }
//     //   ],
//     //   dateOfBirth: new Date('04/21/2019')
//     // }
//     this._departmentService.getAllDepartments().subscribe(departments => {
//       this.departments = departments;
//     });
//     this.empForm = new FormGroup({
//       'name': new FormControl('', [
//         Validators.required,
//         Validators.minLength(4),
//         Validators.maxLength(20)
//       ]),
//       'salary': new FormControl('', [
//         Validators.required
//       ]),
//       'permanent': new FormControl(''),
//       'department': new FormControl(''),
//       'dateOfBirth': new FormControl('')
//     });
//     this.employee = this._employeeService.getEmployee(this.empId).pipe(tap(employee => {
//       console.log(employee.dateOfBirth);
//       this.empForm.patchValue({
//         name: employee.name,
//         salary: employee.salary,
//         permanent: employee.permanent,
//         dateOfBirth: employee.dateOfBirth,
//         department: employee.department
//       });
//     }
//     ));
//     // this._employeeService.getEmployee(this.empId).subscribe((employee: Employee) => {
//     //   this.employee = employee;
//     //   if(employee){
//     //     this.empForm.patchValue({
//     //       'name': this.employee.name,
//     //       'salary': this.employee.salary,
//     //       'permanent': this.employee.permanent,
//     //       'department': this.employee.department
//     //     });
//     //   }

//     // for (let department of this.departments) {
//     //   if (department.id === this.employee.department.id) {
//     //     this.empForm.controls['department'].setValue(department);
//     //     break;
//     //   }
//     // }
//     // });
//   }
//   get name() { return this.empForm.get('name'); }
//   get salary() { return this.empForm.get('salary'); }
//   get permanent() { return this.empForm.get('permanent'); }
//   get department() { return this.empForm.get('department'); }
//   compareById(department: Department, employeeDepartment: Department) {
//     return department && employeeDepartment ? department.id == employeeDepartment.id : department === employeeDepartment;
//   }
//   onSubmit() {
//     this.updatedEmployee = {
//       id: parseInt(this.empId),
//       name: this.empForm.value.name,
//       salary: this.empForm.value.salary,
//       permanent: this.empForm.value.permanent,
//       department: this.empForm.value.department,
//       dateOfBirth: this.empForm.value.dateOfBirth
//     };
//     // console.log(this.updatedEmployee);
//     this._employeeService.updateEmployee(this.updatedEmployee).subscribe(
//       data => {
//         console.log('Employee update successful.');
//         this.error = '';
//       },
//       error => {
//         console.log(error);
//         this.error = error.error.message;
//         if (error.error.errors != null) {
//           this.error = error.error.errors[0];
//         }
//       });
//   }
// }
