import { Injectable } from '@angular/core';
import { HttpHeaders, HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { User } from './user';

const httpOptions = {
  headers: new HttpHeaders({
    'Content-Type': 'application/json',
    'Authorization': 'my-auth-token'
  })
};
@Injectable({
  providedIn: 'root'
})
export class UserService {
  // usersUrl = 'https://reqres.in/api/users';
  usersUrl = 'api/users';  // URL to web api
  constructor(private _http: HttpClient) { }

  getUsers(): Observable<User[]> {
    return this._http.get<User[]>(this.usersUrl);
  }

  searchUsers(term: string): Observable<User[]> {
    term = term.trim();
    const options = term ?
      { params: new HttpParams().set('first_name', term) } : {};
    return this._http.get<User[]>(this.usersUrl, options);
  }
  addUser(user: User): Observable<User> {
    return this._http.post<User>(this.usersUrl, user, httpOptions);
  }
  deleteUser(id: number): Observable<{}> {
    const url = `${this.usersUrl}/${id}`; // DELETE api/heroes/42
    return this._http.delete(url, httpOptions);
  }

  updateUser(hero: User): Observable<User> {
    httpOptions.headers =
      httpOptions.headers.set('Authorization', 'my-new-auth-token');

    return this._http.put<User>(this.usersUrl, hero, httpOptions);
  }
}
