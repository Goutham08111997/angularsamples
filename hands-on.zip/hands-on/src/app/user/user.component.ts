import { Component, OnInit } from '@angular/core';
// import { UserService } from '../user.service';
import { UserService } from './user.service';
import { User } from './user';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit {
  // serviceResponse: string;
  // errorResponse:string='';

  users: User[];
  editUser: User;
  constructor(private _userService: UserService) { }

  ngOnInit() {
    this.getUsers();
  }

  getUsers(): void {
    this._userService.getUsers()
      .subscribe(users => (this.users = users));
  }

  add(name: string): void {
    this.editUser = undefined;
    name = name.trim();
    if (!name) {
      return;
    }

    // The server will generate the id for this new hero
    const newUser: User = { first_name: name } as User;
    this._userService
      .addUser(newUser)
      .subscribe(user => this.users.push(user));
  }

  delete(user: User): void {
    this.users = this.users.filter(u => u !== user);
    this._userService
      .deleteUser(user.id)
      .subscribe();
    /*
    // oops ... subscribe() is missing so nothing happens
    this.heroesService.deleteHero(hero.id);
    */
  }

  edit(user: User) {
    this.editUser = user;
  }

  search(searchTerm: string) {
    // console.log('inside search');
    this.editUser = undefined;
    if (searchTerm) {
      // console.log(searchTerm);
      this._userService
        .searchUsers(searchTerm)
        .subscribe(users => (this.users = users));
    }
  }

  update() {
    if (this.editUser) {
      this._userService
        .updateUser(this.editUser)
        .subscribe(user => {
          // replace the hero in the heroes list with update from server
          const ix = user ? this.users.findIndex(u => u.id === user.id) : -1;
          if (ix > -1) {
            this.users[ix] = user;
          }
        });
      this.editUser = undefined;
    }
  }
}

  // getAction() {
  //   this._userService.getAllUsers().subscribe(
  //     users => this.serviceResponse = JSON.stringify(users.data),
  //     error => console.log("error " + error)
  //   );
  // }
  // postAction() {
  //   this._userService.createUser().subscribe(
  //     postResponse => this.serviceResponse = JSON.stringify(postResponse),
  //     error => console.log("error " + error)
  //   );
  // }
  // putAction() {
  //   this._userService.updateUser().subscribe(
  //     postResponse => this.serviceResponse = JSON.stringify(postResponse),
  //     error => console.log("error " + error)
  //   );
  // }
  // deleteAction() {
  //   this._userService.deleteUser().subscribe(
  //     deleteAction => this.serviceResponse = JSON.stringify(deleteAction),
  //     error => console.log("error " + error)
  //   );
  // }
