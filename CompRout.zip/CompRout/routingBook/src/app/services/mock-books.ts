import { Book } from './book';

export var BOOKS: Book[] = [
  {"id": 1, "name": "Core Java", "price": "25.50", "description": "Core Java Tutorials"},
  {"id": 2, "name": "Angular", "price": "15.20", "description": "Learn Angular"},
  {"id": 3, "name": "Hibernate", "price": "13.50", "description": "Hibernate Examples"},
  {"id": 4, "name": "TypeScript", "price": "26.40", "description": "TypeScript Tutorials"}
];