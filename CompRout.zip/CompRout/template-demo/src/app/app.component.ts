import { Component, ElementRef ,ViewChild , AfterViewInit } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent  implements AfterViewInit {

ngAfterViewInit() {
  this.nameElementRef.nativeElement.f

}
  userName : string;

  private _studentName : string;

@ViewChild('nameRef') nameElementRef: ElementRef;

set studentName(): string 
   return this._studentName;
 }

get studentName(value:  string{
    this._studentName = value;
    if(value == 'raja') {
      alert ("welcome to cognizant");
    }

 }

  increaseCount(){
    this.count +=1;
  }
  

  testNow(userName) {
    this.userName = userName;

    if(this.userName == 'Aswin') {
      alert("hello"+this.userName)
    }

  }
}
