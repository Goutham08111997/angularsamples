import { Component, OnInit } from '@angular/core';
import { WelcomeService } from '../welcome.service';

@Component({
  selector: 'app-child',
  templateUrl: './child.component.html',
  styleUrls: ['./child.component.css']
})

export class ChildComponent implements OnInit {
  constructor(private _welcomeService: WelcomeService) { }

  
  ngOnInit() {
    this._welcomeService.teacherGreeted$.subscribe(
      message => {
        if (message === 'Good Morning Guys') {
          alert('Good Morning Aswin!');
        } else if (message === 'Exam Postponed') {
          alert('Thank you Aswin!');
        }
      }
    );
  }


  

}
