import { Component } from '@angular/core';
import { WelcomeService } from './welcome.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  

  constructor(private _welcomeService: WelcomeService) { }

  welcomeStudent() {
    this._welcomeService.greet('Good Morning Guys');
  }
  infoStudent() {
    this._welcomeService.greet('Exam Postponed');
  }
}
