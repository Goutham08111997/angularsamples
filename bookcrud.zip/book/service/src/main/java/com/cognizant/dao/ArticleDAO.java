package com.cognizant.dao;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cognizant.entity.Article;



public class ArticleDAO implements IArticleDAO {
	
	private EntityManager  entityManager ;
	
	
	public Article getArticleById(int articleId){
		return entityManager.find(Article.class, articleId);
		
	}
	public List<Article> getAllArticles() {

		  String hql = " FROM  Article  as atc  ORDER BY atc.articleID desc ";
	     return (List<Article>)  entityManager.createQuery(hql).getResultList();  
		  			
	}
	
	public void createArticle(Article article) {
	entityManager.persist(article);
	}
	
	public void deleteArticle(int articleId){
		
	  entityManager.remove(getArticleById(articleId));
	}
	
	public boolean articleExists(String title, String category) {
	
	String hql = "FROM Article as atc where atc.title = ? and atc.category = ? ";
	    
	    int count=   entityManager.createQuery(hql).setParameter(1, title).setParameter(2, category).getResultList().size();
		 
	    return count > 0 ? true : false;
		
		
	}
	
	public void updateArticle(Article article) {
		
		Article  art = getArticleById(article.getArticleId());
		
		art.setArticleId(article.getArticleId());
		art.setCategory(article.getCategory());
				
	}
	
	
	
	
	
	
}