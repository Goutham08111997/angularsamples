package com.cts.genc.book.web;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.Link;
import org.springframework.hateoas.Resources;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import static org.springframework.hateoas.mvc.ControllerLinkBuilder.linkTo;
import static org.springframework.hateoas.mvc.ControllerLinkBuilder.methodOn;

import com.cts.genc.book.domain.Product;
import com.cts.genc.book.exception.ProductAlreadyExistsException;
import com.cts.genc.book.exception.ProductNotFoundException;
import com.cts.genc.book.exception.ProductNotValidException;
import com.cts.genc.book.service.ProductService;

@RestController
@RequestMapping("/api/products")
public class ProductController {

	private final Logger log = LoggerFactory.getLogger(ProductController.class);
	
	@Autowired
	ProductService service;

	@GetMapping(produces = "application/json")
	public Resources<Product> getProducts() {
		
		log.debug("Fetching products...");
		
		List<Product> products = service.getProducts();
		
		for(final Product prod : products) {
			Link selfLink = linkTo(methodOn(ProductController.class).getProduct(prod.getCode())).withRel("product");
			prod.add(selfLink);
		}
		
		Link link = linkTo(methodOn(ProductController.class).getProducts()).withRel("products");
		return new Resources<Product>(products, link);
	}
	
	@GetMapping(path="/{id}", produces = "application/json")
	public Product getProduct(@PathVariable("id") String code) {
		
		Product product = null;
		if(code != null && !"".equals(code)) {
			try {
				product = service.getProduct(code);
			} catch (ProductNotFoundException e) {
				throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Product Not found");
			}
		}
		return product;
	}
	
	//Create Product
	@PostMapping
	public Product createProduct(@Valid @RequestBody Product product) {
		try {
			this.service.addProduct(product);
		} catch (ProductAlreadyExistsException e) {
			throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Product with title already exists");
		}
		return product;
	}
	
	//Edit Product
	@PutMapping("/{id}")
	public void updateProduct(@PathVariable("id") String code, @RequestBody Product product) {
		if(code != null && !"".equals(code)) {
			try {
				product.setCode(code);
				service.updateProduct(product);
			} catch (ProductNotFoundException e) {
				throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Invalid request");
			} catch (ProductNotValidException e) {
				throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Product info is not valid");
			}
		}
	}
	
	//Remove Product
	@DeleteMapping("/{id}")
	public void removeProduct(@PathVariable("id") String code) {
		if(code != null && !"".equals(code)) {
			try {
				service.removeProduct(code);
			} catch (ProductNotFoundException e) {
				throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Unable to remove. Product Not found");
			}
		}
	}
	
	//$ curl http://localhost:8080/products/search?title=TV
	@GetMapping(path="/search", produces = "application/json")
	public ArrayList<Product> findProducts(@RequestParam String title) {	
		System.out.println("Title to be used for search: "+title);
		return service.getProducts();
	}
	
	//Filter Product
	//$ curl -X POST -F 'name=abc' -F 'id=123' http://localhost:8080/products/filter
	@PostMapping(path="/filter", produces = "application/json")
	public ArrayList<Product> filterProducts(@RequestParam Map<String,String> params) {	
		params.entrySet().stream().forEach((k)->{
			System.out.println(k.getKey()+" "+k.getValue());
		});
		return service.getProducts();
	}
	
}
