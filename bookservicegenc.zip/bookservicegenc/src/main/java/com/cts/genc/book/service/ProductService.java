package com.cts.genc.book.service;

import java.util.ArrayList;
import java.util.NoSuchElementException;
import java.util.UUID;
import java.util.stream.Stream;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.stereotype.Service;

import com.cts.genc.book.domain.Product;
import com.cts.genc.book.exception.ProductAlreadyExistsException;
import com.cts.genc.book.exception.ProductNotFoundException;
import com.cts.genc.book.exception.ProductNotValidException;

@Service
public class ProductService implements InitializingBean {

	private final Logger log = LoggerFactory.getLogger(ProductService.class);
	
	ArrayList<Product> products = new ArrayList<Product>();

	public ArrayList<Product> getProducts() {
		log.debug("Retrieve products from service");
		// Temporary - to be removed on real implementation
		return products;
	}

	@Override
	public void afterPropertiesSet() throws Exception {
		// Temporary - to be removed on real implementation
		products.add(new Product("1", "One Minute Manager"));
		products.add(new Product("2", "Think and Grow Rich"));
		products.add(new Product("3", "Power of Subconsious mind"));
	}

	public Product getProduct(String code) throws ProductNotFoundException {

		// Temporary - to be removed on real implementation
		Stream<Product> p = products.stream().filter(product -> product.getCode().equals(code));
		Product product = null;
		try {
			product = p.findAny().get();
		} catch (NoSuchElementException e) {
			throw new ProductNotFoundException();
		}

		return product;
	}

	public ArrayList<Product> findByCriteria(String title, boolean partialMatch) {
		// TODO Auto-generated method stub
		return null;
	}

	public void addProduct(Product product) throws ProductAlreadyExistsException {
		if ("Same".equals(product.getTitle())) {
			throw new ProductAlreadyExistsException();
		}
		UUID uniqueKey = UUID.randomUUID();
		product.setCode(uniqueKey.toString());
		this.products.add(product);
	}

	public void updateProduct(Product product) throws ProductNotFoundException, ProductNotValidException {

		if ("".equals(product.getTitle())) {
			throw new ProductNotFoundException();
		}

		if ("Same".equals(product.getTitle())) {
			throw new ProductNotValidException();
		}

	}

	public void removeProduct(String code) throws ProductNotFoundException {
		Stream<Product> p = products.stream().filter(product -> product.getCode().equals(code));
		if (p != null) {
			try {
				Product product = p.findAny().get();
				products.remove(product);
			} catch (Exception e) {
				throw new ProductNotFoundException();
			}
		}
	}

}
