package com.cts.genc.book.service;

import java.util.ArrayList;
import java.util.NoSuchElementException;
import java.util.Optional;
import java.util.stream.Stream;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.cts.genc.book.domain.User;

@Service
public class UserService implements InitializingBean {

	private final Logger log = LoggerFactory.getLogger(UserService.class);

	@Autowired
	PasswordEncoder passwordEncoder;
	
	ArrayList<User> users = new ArrayList<User>();

	public ArrayList<User> getUsers() {
		log.debug("Retrieve users from service");
		// Temporary - to be removed on real implementation
		return users;
	}

	public Optional<User> getUser(String login) throws Exception{

		// Temporary - to be removed on real implementation
		Stream<User> p = users.stream().filter(user -> user.getUsername().equals(login));
		User user = p.findAny().get();
		return Optional.of(user);
	}

	public Optional<User> findOneByLogin(String login) {
		return null;
	}

	public Optional<User> findOneByEmailIgnoreCase(String email) {
		return null;
	}

	public User createUser(@Valid User user) {
		
		//TODO: return error if ID already present
		
		users.add(user);
		
		log.debug("Created Information for User:", user);
		return user;
	}

	@Override
	public void afterPropertiesSet() throws Exception {
		User user = new User("John", "john", "john@email.com", passwordEncoder.encode("Test123"));
		user.addRole("ROLE_USER");
		users.add(user);
	}

}
