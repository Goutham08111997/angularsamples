package com.cts.genc.book.security.jwt;

public class JwtAuthResponse {

	private String token;
	private String type = "Authorization";

	public JwtAuthResponse(String token) {
		super();
		this.token = token;
	}

	public String getToken() {
		return token;
	}

	public void setToken(String token) {
		this.token = token;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

}
