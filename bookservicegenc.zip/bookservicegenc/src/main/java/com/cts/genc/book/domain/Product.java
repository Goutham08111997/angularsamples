package com.cts.genc.book.domain;

import javax.validation.constraints.NotNull;

import org.springframework.hateoas.ResourceSupport;

public class Product extends ResourceSupport {
	
	private String code;
	
	@NotNull(message = "TITLE is required")
	private String title;
	private double price;

	public Product() {
		super();
	}

	public Product(String title) {
		super();
		this.title = title;
	}
	
	public Product(String code, String title) {
		super();
		this.code = code;
		this.title = title;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

}
